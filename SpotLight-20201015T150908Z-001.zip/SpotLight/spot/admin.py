from django.contrib import admin
from .models import StudInfo, winners
# Register your models here.

admin.site.register(StudInfo)
admin.site.register(winners)