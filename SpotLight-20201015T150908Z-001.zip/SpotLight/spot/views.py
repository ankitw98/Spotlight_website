from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from .models import StudInfo
from .models import Notice
from spot.models import Notice
from spot.forms import noticeForm
from django.contrib import messages
from django.views.decorators.cache import cache_control
# Create your views here.

def index(request):
    note=Notice.objects.all()
    return render(request, "spot/front.html",{'my_note':note})


def login(request):
    return render(request, "spot/login.html")


def register(request):
    return render(request, "spot/register.html")


def admin(request):
            return render(request, "spot/admin.html")


def ppt(request):
    return render(request, "spot/ppt.html")


def gd(request):
    return render(request, "spot/gd.html")


def notice(request):
    note = Notice.objects.all()
    return render(request, "spot/notice.html",{'my_note':note})

#@cache_control(no_cache=True, must_revalidate=True, no_store=True)
def home(request):

    reg_stud = StudInfo.objects.all()

    if request.method == "POST":
        name1 = request.POST.get("name", False)
        password = request.POST.get("branch", False)
        # print(password)
        if(name1=="admin" and password=="admin"):
            return render(request, "spot/admin.html")
        for i in reg_stud:

            if (name1==i.name and password==i.branch):
                user = 1
                break
            else:
                user = 0

        if (user==1):
            print("Login successfull")
            return render(request, "spot/home.html")
        else:

            print("Incorrect  credentials")
            return render(request,"spot/login.html")
    else:
        print("Credentials not entered")
    return render(request, "spot/index.html")


def insert_data(request):
    print("Form is submited")
    name = request.POST["name"]
    branch = request.POST["branch"]
    mob_no = request.POST["mob_no"]

    stud_info = StudInfo(name=name, branch=branch, mob_no=mob_no)
    stud_info.save()
    return render(request, "spot/register.html")


def insert_data1(request):
    print("Form is submited")
    notice_text = request.POST["notice_text"]

    notice = Notice(notice_text=notice_text)
    notice.save()
    return render(request, "spot/admin.html")


def show(request):
    reg_stud = StudInfo.objects.all()
    return render(request, "spot/show.html", {'Info': reg_stud})


def edit(request,id):
    note = Notice.objects.get(id=id)
    return render(request, "spot/edit.html", {'note': note})


def update(request, id):
    ins = Notice.objects.get(id=id)
    form = noticeForm(request.POST, instance=ins)
    print(form)
    if form.is_valid():
        form.save()
        return redirect("/spot/notice/")
    return render(request,"spot/edit.html",{'ins': ins})


def delete(request,id):
    note = Notice.objects.get(id=id)
    note.delete()
    return redirect("/spot/notice/")