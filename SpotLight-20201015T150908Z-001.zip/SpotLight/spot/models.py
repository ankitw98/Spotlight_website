from django.db import models

# Create your models here.
class StudInfo(models.Model):
    name= models.CharField(max_length=30)
    branch= models.CharField(max_length=20)
    mob_no = models.CharField(max_length=10)


    def __str__(self):
        return self.name

class Notice(models.Model):
    notice_text= models.CharField(max_length=100)
    def __str__(self):
        return self.notice_text

class winners(models.Model):
    win_name = models.CharField(max_length=20)
    branch = models.CharField(max_length=20)
    Event = models.CharField(max_length=20)
    mob_no = models.CharField(max_length=10)
    class meta:
        db_table = "winners"

    def __str__(self):
        return self.win_name