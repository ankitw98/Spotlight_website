from django.apps import AppConfig


class SpotConfig(AppConfig):
    name = 'spot'
