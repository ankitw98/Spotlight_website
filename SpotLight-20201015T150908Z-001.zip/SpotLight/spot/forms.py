from django import forms
from spot.models import Notice

class noticeForm(forms.ModelForm):
    class Meta:
        model = Notice
        fields = "__all__"