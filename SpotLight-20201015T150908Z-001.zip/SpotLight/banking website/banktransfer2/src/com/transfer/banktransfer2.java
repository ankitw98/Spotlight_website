package com.transfer;
//codota.com for java
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/banktransfer2")
public class banktransfer2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
   	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		checking c=new checking();
		try
		{
			long Ano1,Ano2;
			RequestDispatcher dispatcher;
			Ano1=Long.valueOf((request.getParameter("Ano")));
			Ano2=Long.valueOf((request.getParameter("TAno")));
			String email=request.getParameter("Uname");
			String password=request.getParameter("pass");
			int u=c.checkLogin(Ano1, Ano2, email, password);
			System.out.println("u:"+u);
			if(u==1)
			{
				final String jdbc_driver="com.mysql.cj.jdbc.Driver";
				final String db_url="jdbc:mysql://localhost/bank";
				final String user="root";
				final String passw="admin";
				System.out.println("hii");
				Connection conn=null;
				PreparedStatement stmt = null;
				Class.forName(jdbc_driver);
			    System.out.println("Connecting to a selected database...");
			    conn = DriverManager.getConnection(db_url,user, passw);
			    System.out.println("Connected database successfully...");
			    stmt=conn.prepareStatement("select *from account where Ano=?");
			    Ano1=Long.valueOf((request.getParameter("Ano")));
			    stmt.setLong(1, Ano1);
			    ResultSet rs=stmt.executeQuery();
			    rs.next();
			    long amount1=rs.getLong("amount");
			    if(amount1>0)
			    {
				    long amount2=Long.valueOf((request.getParameter("Amount")));
			    	amount1=amount1-amount2;
				    stmt = conn.prepareStatement("update account set amount=? where Ano=?");
				    stmt.setLong(1, amount1);
				    stmt.setLong(2, Ano1);
				    stmt.executeUpdate();
				    System.out.println("update user's account");
				    
				    stmt=conn.prepareStatement("select *from account where Ano=?");
				    Ano1=Long.valueOf((request.getParameter("TAno")));
				    stmt.setLong(1, Ano1);
				    rs=stmt.executeQuery();
				    System.out.println("found user's account....");
				    rs.next();
				    amount1=rs.getLong("amount");
				    System.out.println("found user's account....");
				    amount1=amount1+amount2;
				    stmt = conn.prepareStatement("update account set amount=? where Ano=?");
				    stmt.setLong(1,amount1 );
				    stmt.setLong(2, Ano1);
				    stmt.executeUpdate();
				    System.out.println("amount transfer successfully\nThank you!");
				    dispatcher = request.getRequestDispatcher("result.html");
			    }
			    else
			    	dispatcher = request.getRequestDispatcher("NoAmount.html");
			}
			else
				dispatcher = request.getRequestDispatcher("error.html");
		    dispatcher.forward(request, response);
		}
		catch(Exception e)
		{
			System.out.println("wrong");
		  	  e.printStackTrace();
		}
	}
}
