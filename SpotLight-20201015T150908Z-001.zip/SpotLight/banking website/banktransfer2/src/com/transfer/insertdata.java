package com.transfer;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class insertdata
 */
@WebServlet("/insertdata")
public class insertdata extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
      


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 try{
			 
			   final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
			   final String DB_URL = "jdbc:mysql://localhost/stud" ;

			   final String USER = "root";
			   final String PASS = "admin";
				
				
				 Connection conn = null;
				 PreparedStatement stmt = null;
			   
			 
			 //2
			 Class.forName(JDBC_DRIVER);
		
			 
			 //3
			 
			 System.out.println("Connecting to a selected database...");
			 conn = DriverManager.getConnection(DB_URL,USER,PASS);
			 System.out.println("Connected database successfully.....");
			 
			 //4
			 System.out.println("Inserting record into the table...");
			 stmt = conn.prepareStatement("insert into student values(?,?) ");
			 stmt.setInt(1,Integer.valueOf(request.getParameter("id")));
			 
			 stmt.setString(2,request.getParameter("name"));
			 
			 stmt.executeUpdate();
			 System.out.println("Inserted record into the table...");
			 
			 
			 
		      }
		      catch(Exception e)
		     {
		    	 System.out.println("wrong");
		    	 e.printStackTrace();
		     }
	
	}

}
