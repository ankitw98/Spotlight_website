package com.transfer;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Check {

	public int checkLogin(Long anows, String userws, String passws) throws SQLException,
	ClassNotFoundException
	{
		long anodb ;
		String userdb, passdb;
		
		// JDBC driver name and database URL
	    final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
	    final String DB_URL = "jdbc:mysql://localhost/bank";

	   //  Database credentials
	    final String USER = "root";
	    final String PASS = "admin";
		
		Connection conn = null;
		@SuppressWarnings("unused")
		PreparedStatement stmt = null;
	
		//STEP 2: Register JDBC driver
		Class.forName(JDBC_DRIVER);
		
		//STEP 3: Open a connection
	
		conn = DriverManager.getConnection(DB_URL, USER, PASS);
		String sql = "SELECT * FROM account";
		PreparedStatement statement = conn.prepareStatement(sql);
		ResultSet result = statement.executeQuery();

		while (result.next())		//Take values from database
		{
			anodb = result.getLong(1);
			userdb = result.getString(2);
			passdb = result.getString(4);
			if(anodb==anows && userdb.equals(userws) && passdb.equals(passws))
			{
				conn.close();
				return 1;  
			}
  		}
		conn.close();
		return 0;
	}

}
