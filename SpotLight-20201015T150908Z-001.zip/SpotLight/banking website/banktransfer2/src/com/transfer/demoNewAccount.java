package com.transfer;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
/**
 * Servlet implementation class NewAccount2
 */
@WebServlet("/demoNewAccount")
public class demoNewAccount extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	//--------------------------------------- STEP 1 ----------------------------------------
	final String DB_URl = "jdbc:mysql://localhost/bank";
	final String user = "root";
	final String pass = "admin";
	
	Connection conn = null;
	PreparedStatement stmt = null;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		
		try
		{
			RequestDispatcher dispatcher;
			//--------------------------------------- STEP 2 ----------------------------------------
			Class.forName("com.mysql.cj.jdbc.Driver");
			//--------------------------------------- STEP 3 ----------------------------------------
			conn = DriverManager.getConnection(DB_URl,user,pass);
			//--------------------------------------- STEP 4 ----------------------------------------
			stmt = conn.prepareStatement("insert into account(Uname,pass,amount,Address,Phone) values(?,?,?,?,?)");
			stmt.setString(1, request.getParameter("Uname"));
		    stmt.setString(2, request.getParameter("pass"));
		    //stmt.setString(3, request.getParameter("rpass"));
		    stmt.setLong(3, Long.valueOf(request.getParameter("Amount"))); 
		    stmt.setString(4, request.getParameter("Address"));
		    stmt.setLong(5, Long.valueOf(request.getParameter("Phone"))); 
		    stmt.executeUpdate();
		    System.out.println("Inserted records into the table...");
		  //--------------------------------------- DONE ----------------------------------------
		    dispatcher = request.getRequestDispatcher("newaccountresult.html");
		    dispatcher.forward(request, response);
		   // response.getWriter().append("Served at: ").append(request.getContextPath());
		}
		catch(Exception e)
		{
			System.out.println("Error!!!");
			e.printStackTrace();
		}
		finally
		{
		      //finally block used to close resources
		      try
		      {
			         if(stmt!=null)
			            conn.close();
		      }
		      catch(SQLException se){}// do nothing
		      try
		      {
			         if(conn!=null)
			            conn.close();
		      }
		      catch(SQLException se)
		      {
		    	  	se.printStackTrace();
		      }
		}//end finally try
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
		doGet(request, response);
	}
}
