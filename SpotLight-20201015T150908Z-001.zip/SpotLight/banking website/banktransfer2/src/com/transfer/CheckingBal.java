package com.transfer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CheckingBal {
	public int checkLogin(long no,String email, String password) throws SQLException,
    ClassNotFoundException
    {
		final String jdbc_driver="com.mysql.cj.jdbc.Driver";
		final String db_url="jdbc:mysql://localhost/bank";
		final String user="root";
		final String passw="admin";
		int flag=0;
		System.out.println("hii");
		Connection conn=null;
		PreparedStatement stmt = null;
		Class.forName(jdbc_driver);
	    System.out.println("Connecting to a selected database...in checking class");
	    conn = DriverManager.getConnection(db_url,user, passw);
	    System.out.println("Connected database successfully...");
	    stmt=conn.prepareStatement("select*from account");
	    ResultSet rs=stmt.executeQuery();
	    while(rs.next())
	    {
	    	if(password.equals(rs.getString("pass")) && email.equals(rs.getString("Uname"))&&no==rs.getInt("Ano") )
	    	{
	    		flag=1;
	    		break;
	    	}
	    	else
	    		flag=0;
	    }
		return flag;
    }
}
