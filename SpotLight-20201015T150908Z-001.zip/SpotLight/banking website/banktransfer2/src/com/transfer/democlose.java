package com.transfer;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class banktransfer2
 */
@WebServlet("/democlose")
public class democlose extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		checking c=new checking();
		try
		{
			long Ano1;
			RequestDispatcher dispatcher;
			Ano1=Long.valueOf((request.getParameter("Ano")));
			String email=request.getParameter("Uname");
			String password=request.getParameter("pass");
			int u=c.checkLogin1(Ano1, email, password);
			System.out.println("u:"+u);
			if(u==1)
			{
				
				final String jdbc_driver="com.mysql.cj.jdbc.Driver";
				final String db_url="jdbc:mysql://localhost/bank";
				final String user="root";
				final String passw="admin";
				System.out.println("hii");
				Connection conn=null;
				PreparedStatement stmt = null;
				Class.forName(jdbc_driver);
			    System.out.println("Connecting to a selected database...");
			    conn = DriverManager.getConnection(db_url,user, passw);
			    System.out.println("Connected database successfully...");
			    
			    System.out.println("get record into table");
			    stmt = conn.prepareStatement("select * from account where Ano=?");
			    stmt.setLong(1, Ano1);
		         ResultSet rs =stmt.executeQuery();
		         rs.next();
		         long Amount=rs.getLong("amount");
		         String address=rs.getString("Address");
		         long phone=rs.getLong("Phone");
				 
			  
			    System.out.println("inserting record into table");
			       stmt = conn.prepareStatement("insert into account1(Ano,Uname,pass,amount,Address,Phone) values(?,?,?,?,?,?)");
			       stmt.setLong(1,Ano1);
			       stmt.setString(2,email);
			       stmt.setString(3,password);
			       stmt.setLong(4,Amount);
			       stmt.setString(5,address);
			       stmt.setLong(6,phone);
				   stmt.executeUpdate(); 
			     
				 System.out.println("deleting record into table");
			      stmt = conn.prepareStatement("DELETE FROM account where Ano=?");
				   stmt.setLong(1,Ano1);
				   stmt.executeUpdate();
				   dispatcher = request.getRequestDispatcher("accountclose.html");   					 
			}
			else
				dispatcher = request.getRequestDispatcher("error.html");
			dispatcher.forward(request, response);
		}
		catch(Exception e)
		{
			System.out.println("wrong");
		  	  e.printStackTrace();
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
