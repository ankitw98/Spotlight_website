package com.transfer;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

/**
 * Servlet implementation class Deposit2
 */
@WebServlet("/demodeposit")
public class demodeposit extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	final String db_url = "jdbc:mysql://localhost/bank";
	final String user = "root";
	final String password = "admin";
	
	Connection conn = null;
	PreparedStatement stmt =null;
	
	Long Ano1, amountdb, amountws;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		try
		{
			Check c = new Check();
			RequestDispatcher dispatcher;
			long Anows;		
			String userws,passws;
			
			Anows = Long.parseLong(request.getParameter("Ano"));	//Take Account number from website
			userws = request.getParameter("Uname");		//Take Username number from website
			passws = request.getParameter("pass");		//Take password number from website
			
			PrintWriter out=response.getWriter();	//TO print on website
			
			int u=c.checkLogin(Anows, userws, passws);		//Passing values from website to method as arguments
			System.out.println("u:"+u);		//Returned value of checkLogin method
			
			if(u==1)	//IF RIGHT CREDENTIALS ARE ENTERED
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				conn = DriverManager.getConnection(db_url,user,password);
				stmt = conn.prepareStatement("Select * from account where Ano = ?");	
				Ano1 = Long.valueOf((request.getParameter("Ano")));
				stmt.setLong(1, Ano1);
				
				ResultSet rs=stmt.executeQuery();
				rs.next();
				amountdb=rs.getLong("Amount");	//Take amount from database
				amountws = Long.valueOf((request.getParameter("Amount")));	//Take amount from website
				 
				amountdb = amountdb + amountws;
				 
				stmt = conn.prepareStatement("update account set Amount=? where Ano=?");	//Updating amoumt
			    stmt.setLong(1,amountdb);
			    stmt.setLong(2,Ano1);
			    stmt.executeUpdate();
			    dispatcher = request.getRequestDispatcher("depositresult.html");
			    System.out.println("Updated user's account");
			}
			else
				dispatcher = request.getRequestDispatcher("error.html");
		    dispatcher.forward(request, response);

		}
		catch(Exception e)
		{
			System.out.println("Error !!!");
			e.printStackTrace();
		}
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
		doGet(request, response);
	}

}
